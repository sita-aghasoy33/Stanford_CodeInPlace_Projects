from graphics import Canvas
import secrets
from ai import call_gpt
    
CANVAS_WIDTH = 400
CANVAS_HEIGHT = 400
MAX_CHANCES = 10
SHIP_WIDTH = 100
SHIP_HEIGHT = 50
BULLET_SIZE = 10

def main():
    """
    This function is Battleship game in a simple format!
        1. A hidden ship is on the screen.
        2. You have 10 chances to find and click on it.
        3. Click anywhere on the screen to make your guess.
        4. If you click the ship, you win!
        5. If you use all 10 chances without finding the ship, you lose.
    
    It gets user input for preffered language and tries to support Player
    within the game with chosen language with GPT.

    This game has been prepared with the help of below-mentioned packages.
        - graphics to create Canvas object for the main structure of the game.
        - secrets as random generator
        - AI for call_gpt() function for translation and Player support.

    Disclaimer: Even though the prompts have been prepared carefully, GPT may translate false sometimes.
    Sorry for inconvenience due to AI capabilities and halucination.
    """
    # create canvas
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT+80)

    # Welcome the player.
    print("Welcome to Battleship game.")

    # Get the preferred language.
    language = input("Please enter the language you prefer: ")

    # prepare translation prompt
    translation_promt = f"Translate the following sentence into [{language}]. Only output the translated sentence. Do not explain. Eliminate the '' sign:"
    print(call_gpt(f"Write a short and direct set of game instructions that speak directly to the player. The game is built using the Canvas package. There is a hidden ship on the screen. The player has 10 chances to find and click on the ship. If they succeed, they win. If they fail, they lose. Do not explain or comment—just present the rules directly to the player in {language} language."))
    
    # create header text
    text_box, result_text, description = create_header(canvas)

    # create the rectangle ship
    left_x = secrets.randbelow(CANVAS_WIDTH-SHIP_WIDTH)
    top_y = secrets.randbelow(CANVAS_HEIGHT-SHIP_HEIGHT) + 80
    right_x = left_x + SHIP_WIDTH
    bottom_y = top_y + SHIP_HEIGHT
    rect = canvas.create_rectangle(
        left_x,
        top_y,
        right_x,
        bottom_y,
        "green")

    # make the rectangle hidden
    canvas.set_hidden(rect, True)

    # initialize the player score
    score = 0

    # try several chances to shoot the ship
    for i in range(MAX_CHANCES): # as much as thenumber of maximum chances
        # get the user click on canvas
        canvas.wait_for_click()
        click = canvas.get_last_click()

        # get the coordinates of click
        x = click[0]
        y = click[1]

        # create an oval to show the shoot
        shoot = canvas.create_oval(x,
            y,
            x+10,
            y+10,
            'black')

        # print the coordinates of click in the console
        print("click", click)
        
        # check wether the click (shoot) overlaps with ship
        objs = canvas.find_overlapping(
            x, 
            y, 
            x+10, 
            y+10)
        
        # if it overlaps print out "You did it!" and break the loop.
        print(objs[0] == rect)
        if objs[0] == rect:
            score = 1
            text = call_gpt(translation_promt + "'You did it!'")
            # show the number of left chances
            descrpt = call_gpt(translation_promt + "'Congratulations!'")

            # change the text with the new message for each shoot.
            canvas.change_text(result_text, text)
            canvas.change_text(description, descrpt)
            break

        else: # if not print out "Missed Out!" and continue till the end of the loop.
            text = call_gpt(translation_promt +"'Missed out!'")

            # show the number of left chances
            descrpt = call_gpt(translation_promt + f"'{MAX_CHANCES-(i+1)} chances left.'")

        # change the text with the new message for each shoot.
        canvas.change_text(result_text, text)
        canvas.change_text(description, descrpt)


    # show the number of left chances
    if score == 1:
        text = call_gpt(translation_promt + "'You won!'")
    else:
        text = call_gpt(translation_promt + "'Game Over!'")
        descrpt = call_gpt(translation_promt + "'Try this game next time!'")


    # change the text with the new message for each shoot.
    canvas.change_text(result_text, text)
    canvas.change_text(description, descrpt)
       
    # make the rectangle visible to show the result
    canvas.set_hidden(rect, False)
    phrase_from_gpt(score, language)

def phrase_from_gpt(score, language):
    """
    Based on the score gpt gives motivation in chosen language.

    params:
        score (int): it will be either 0, or 1.
                     If it is 0, player has lost, if 1, won.
        language (string): GPT will give the phrase in this given language.
    
    returns:
        text object in Canvas. The result will print out on current canvas.
    """
    # create blank canvas
    canvas = Canvas(CANVAS_WIDTH, CANVAS_HEIGHT+80)

    if score == 1:
        keyword = "won" # if score == 1, tell gpt that player has won.
    else:
        keyword = "lost" # if score == 0, tell that player has lost.

    # generate phrase
    phrase = call_gpt(f"You are talking to a Battleship player who has {keyword}. Tel him/her a max 10 words but touching motivational and advice phrase in {language}")
    
    phrase_text = canvas.create_text(
    5, 
    5, 
    text = phrase,
    font = 'Arial', 
    font_size = 10, 
    color ='purple'
    )
    


def create_header(canvas):
    """
    function creates a text box and initializes the text for game results beforehand.

    returns:
        text_box (canvas rectange): white and black outlined.
        result_text (canvas text): shows if player won or lost.
        description (canvas text): shows the number of chances left and other detailed messages.

        The given text will be changed during the game describing the result of situation.
    """

    # create text box
    text_box = canvas.create_rectangle(
        0,
        0,
        400,
        80,
        'white',
        'black'
    )

    # create main text shows the result
    result_text = canvas.create_text(
        x = 5,
        y = 5, 
        text = "",
        font = 'Arial', 
        font_size = 50, 
        color = "blue"
    )

    # create description
    description = canvas.create_text(
        x = 5,
        y = 55, 
        text = "",
        font = 'Arial', 
        font_size = 25, 
        color = "black"
        )

    return text_box, result_text, description



#========================================
# run the function
if __name__ == '__main__':
    main()